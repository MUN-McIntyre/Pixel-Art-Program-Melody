import cv2
import numpy as np

def resize_image(input_path, output_path, new_width, new_height):
    image = cv2.imread(input_path)
    resized_image = cv2.resize(image, (new_width, new_height))
    cv2.imwrite(output_path, resized_image)

def create_pixels(image, rows, cols):
    height, width, _ = image.shape
    Houtput = height // rows 
    Woutput = width // cols  

    pixelated_image = np.zeros_like(image) #empty image  to start with

    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) #grayscale image
    _, threshold = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY) #threshold to get binary image
    contours, _ = cv2.findContours(threshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #applying contour

    # looping through the grid/pixel blocks
    for i in range(rows):
        for j in range(cols):
            npixel_x, npixel_y = j * Woutput, i * Houtput
            npixel_x_end, npixel_y_end = (j + 1) * Woutput, (i + 1) * Houtput

            pixel = image[npixel_y:npixel_y_end, npixel_x:npixel_x_end] #extracting each pixel
            pixel_mask = cv2.rectangle(np.zeros_like(gray_image), (npixel_x, npixel_y), (npixel_x_end, npixel_y_end), 255, thickness=cv2.FILLED) #filled rectangle to highlight binary mask
            intersection = cv2.bitwise_and(threshold, pixel_mask) #finding common area btw threshold image and pixel block
            contourpercent = np.sum(intersection > 0) / np.sum(pixel_mask > 0) #finidng percentage of contour line in pixel

            if contourpercent > 0.5:
                # using primary color of pixel
                pixelated_image[npixel_y:npixel_y_end, npixel_x:npixel_x_end] = np.mean(pixel, axis=(0, 1)).astype(np.uint8)
            else:
                # using contour color if contourpercent is high, else using main pixel color
                if contourpercent > 0.5:
                    pixelated_image[npixel_y:npixel_y_end, npixel_x:npixel_x_end] = np.mean(pixel, axis=(0, 1)).astype(np.uint8)
                else:
                    contour_color = np.mean(image[npixel_y:npixel_y_end, npixel_x:npixel_x_end], axis=(0, 1)).astype(np.uint8)
                    pixelated_image[npixel_y:npixel_y_end, npixel_x:npixel_x_end] = contour_color

    return pixelated_image

def display_result(image):
    cv2.imshow("Pixel Art Image", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

input_image_path = 'C:/Users/melod/Desktop/3301 Project- AOP/link.jpeg'
output_image_path = 'C:/Users/melod/Desktop/3301 Project- AOP/resized_img.png'

resize_image(input_image_path, output_image_path, 500, 500)

grid_percentage = 5 #can change to adjust pixel/grid size/ use 5 as default

resized_img = cv2.imread(output_image_path)
rows, cols = int(resized_img.shape[0] * grid_percentage / 100), int(resized_img.shape[1] * grid_percentage / 100)
pixel_image= create_pixels(resized_img, rows, cols)
display_result(pixel_image)
